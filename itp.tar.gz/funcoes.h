#ifndef FUNCOES_H
#define FUNCOES_H

void abrir_arquivo(char p[50]){ //função para letitura do arquivo
	FILE *img = fopen(p, "r");
    int L, C;
    fscanf(img, "P6\n%d %d\n255\n", &L, &C);
    
    char vet[L][C];    
    
	for(int i=0;i<L;i++){
		for(int j=0;j<C;j++){
			fscanf(img,"%s ",&vet[i][j]);
		}
	}
    fclose(img);
}

void blank(int dimx,int dimy){
    FILE *fp = fopen("n.ppm", "w");
    if(fp == NULL){
		printf("Erro na abertura do arquivo");
	}
    else{
        fprintf(fp, "P6\n%d %d\n255\n", dimx, dimy);
        fclose(fp);
    }
}

#endif
