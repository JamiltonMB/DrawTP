#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "structs.h"
#include "funcoes.h"


/*void rect(int C, int L, pixel vet[L][C], formas_q q){ //função para desenhar retângulos
    int i, j;
    for(i=q.posy; i<(q.posy+q.tamy); i++)
        {
        for(j=q.posx; j<(q.posx+q.tamx); j++)
            {
            vet[i][j].red=R;
            vet[i][j].green=G;
            vet[i][j].blue=B;
            }
        }
}
*/

int save(int L, int C, pixel **p){ //função para salvar imagens
	int i, j;
	FILE *img = fopen("imagem.ppm", "w");
	if(img == NULL)
		{
		printf("Erro na abertura do arquivo");
		}
	else
		{
		fprintf(img, "P3\n%d %d\n255\n", L,C );
		for(i=0; i<fundo.C; i++)
		    {
		    for(j=0; j<fundo.L; j++)
		        {
		        if(j!=fundo.C-1)
		            {            
		            fprintf(img, "%s %s %s ", p[i][j].red,p[i][j].green,p[i][j].blue);
		            }
		        else
		            {
		            fprintf(img, "%s %s %s ", p[i][j].red, p[i][j].green, p[i][j].blue);
		            }
		        }
		    fprintf(img, "\n");
		    }
		fclose(img);
		}
}


/*int *** aloc_f(int t1, int t2, int t3){
int i, j;

int ***vet = malloc(sizeof(int**)*t1);
for(i=0;i<t1; i++)
	{
	vet[i] = malloc(sizeof(int*)*t2);
	}
for(i=0;i<t1;i++)
	{
	for(j=0;j<t2;j++)
	{
		vet[i][j]=malloc(sizeof(int)*t3);
	}
}
return vet;

}*/

int main(){
   
    /*int ***vet=NULL,op;
    vet = aloc_f(fundo.tamy, fundo.tamx);*/

    printf("Digite uma das opções \n 1 - Abrir arquivo \n2 - Criar arquivo\n3 - Desenhar um retangulo\n0 - Sair");
    scanf("%d",&op);
    do{
        switch(op){
            case 0:
                break;
            case 1:
                printf("Digite o nome do arquivo que quer abrir:");
                scanf("%s",arquivo);
                abrir_arquivo(arquivo);
                break;
            case 2:
                printf("Digite as dimensões da imagem a ser criada:\n");
                printf("Altura:");
                scanf("%d";&c);
                printf("\nLargura:");
                scanf("%d";&l);
                break;
            default:
                printf("Erro");
                break;
        }
    while(op!=0);

return 0;
}
