#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "structs.h"
#include "funcoes.h"

int main(){

    printf("Digite uma das opções \n 1 - Abrir arquivo \n2 - Criar arquivo\n3 - Desenhar um retangulo\n0 - Sair");
    scanf("%d",&op);
    do{
        switch(op){
            case 0:
                break;
            case 1:
                printf("Digite o nome do arquivo que quer abrir:");
                scanf("%s",arquivo);
                abrir_arquivo(arquivo);
                break;
            case 2:
                printf("Digite as dimensões da imagem a ser criada:\n");
                printf("Altura:");
                scanf("%d";&c);
                printf("\nLargura:");
                scanf("%d";&l);
                break;
            default:
                printf("Erro");
                break;
        }
    while(op!=0);

return 0;
}
