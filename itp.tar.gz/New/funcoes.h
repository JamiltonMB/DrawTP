#ifndef FUNCOES_H
#define FUNCOES_H

void abrir_arquivo(char p[50]){ //função para letitura do arquivo
	FILE *img = fopen(p, "r");
    int L, C;
    fscanf(img, "P3\n%d %d\n255\n", &L, &C);
    
    char vet[L][C];    
    
	for(int i=0;i<L;i++){
		for(int j=0;j<C;j++){
			fscanf(img,"%d ",&vet[i][j]);
		}
	}
    fclose(img);
}

void branco(int dimx,int dimy){
    FILE *fp = fopen("n.ppm", "w");
    if(fp == NULL){
		printf("Erro na abertura do arquivo");
	}
    else{
        fprintf(fp, "P3\n%d %d\n255\n", dimx, dimy);
	for(int j=0;j<dimy;j++)
	{
		for(int i=0;i<dimx;i++)
		{
			fprintf(fp,"255 255 255 ");
		}
		fprintf(fp,"\n");
	}
        fclose(fp);
    }
}

#endif
